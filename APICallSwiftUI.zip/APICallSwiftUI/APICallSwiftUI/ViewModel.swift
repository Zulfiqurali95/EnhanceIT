//
//  ViewModel.swift
//  APICallSwiftUI
//
//  Created by Consultant on 3/29/22.
//

import SwiftUI




struct Article : Hashable, Codable {
    let id : Int?
    let title : String?
    let url : String?
    let imageUrl : String?
    let newsSite : String?
    let summary : String?
    let publishedAt : String?
    let updatedAt : String?
    let featured : Bool?
    let launches : [String]?
    let events : [String]?

    enum CodingKeys: String, CodingKey {

        case id = "id"
        case title = "title"
        case url = "url"
        case imageUrl = "imageUrl"
        case newsSite = "newsSite"
        case summary = "summary"
        case publishedAt = "publishedAt"
        case updatedAt = "updatedAt"
        case featured = "featured"
        case launches = "launches"
        case events = "events"
    }

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        url = try values.decodeIfPresent(String.self, forKey: .url)
        imageUrl = try values.decodeIfPresent(String.self, forKey: .imageUrl)
        newsSite = try values.decodeIfPresent(String.self, forKey: .newsSite)
        summary = try values.decodeIfPresent(String.self, forKey: .summary)
        publishedAt = try values.decodeIfPresent(String.self, forKey: .publishedAt)
        updatedAt = try values.decodeIfPresent(String.self, forKey: .updatedAt)
        featured = try values.decodeIfPresent(Bool.self, forKey: .featured)
        launches = try values.decodeIfPresent([String].self, forKey: .launches)
        events = try values.decodeIfPresent([String].self, forKey: .events)
    }

}

public class ViewModel: ObservableObject {
    @Published var articles: [Article] = []
    
    
    
    func fetch() {
        guard let url = URL(string:"https://api.spaceflightnewsapi.net/v3/articles") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self]data, _, error in
            guard let data = data, error == nil  else {
                return
            }
            //convert to json
            do {
                let articles = try JSONDecoder().decode([Article].self, from: data)
                DispatchQueue.main.async {
                    self?.articles = articles
                }
                
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
}

