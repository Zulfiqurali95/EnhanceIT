//
//  APICallSwiftUIApp.swift
//  APICallSwiftUI
//
//  Created by Consultant on 3/29/22.
//

import SwiftUI

@main
struct APICallSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
