import UIKit

let nums = [2,5,3,9,6,7,8,1]
let target = 15
func findTarget (nums :[Int], target:Int) -> (Int,Int){
    var ind1 = 0
    var ind2 = 0

outerLoop:  for x in 0..<nums.count
            
    {
        ind2 = 1
        for y in 1..<nums.count
        {
            
        
        if ( nums[x] + nums [y] == target && (x != y))
            {
                break outerLoop
            }
            ind2+=1
            
        }
    ind1+=1
    }
    return (ind1, ind2)
    }

var targetIndexes = findTarget(nums: nums, target: target)
var ind1 = targetIndexes.0
var ind2 = targetIndexes.1

print("[\(ind1),\(ind2)]")

