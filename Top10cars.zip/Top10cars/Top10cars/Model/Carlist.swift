//
//  Carlist.swift
//  Top10cars
//
//  Created by Consultant on 4/2/22.
//

import Foundation
import SwiftUI
  

struct Car :Identifiable{
let id = UUID()
let title:String
let image:String
let Engine:String
let Layout:String
let Price:String
let url: URL?
}

struct CarList{
    static let topTen = [
        Car(title: "Aston Martin DBS Superleggera", image:"astonMartin", Engine: "5.2L Twin-Turbocharged V12 715 bhp  (533 ), 663 lb⋅ft  (899 N·m)", Layout: "Front-Engined, Rear-Wheel Drive 8-speed Transmission", Price: "From $316,300", url: URL(string: "https://www.youtube.com/watch?v=jJ8Djdfo46c&ab_channel=carwow")),
        Car(title: "Audi", image: "AUDIRS6", Engine: "4.0L Twin-Turbocharged V8 503 bhp  (375 kW), 505 lb⋅ft", Layout: "Front-Engined,Rear-Wheel Drive 8-speed Transmission", Price: "From $116,500", url: URL(string: "https://www.youtube.com/watch?v=Ws24qKTsQS0&ab_channel=TheStraightPipes")),
        Car(title: "Bently", image: "Bently-1", Engine: "6.0L Twin-Turbocharged W12 700 bhp  (522 kW), 750 lb⋅ft  (1017 N·m)", Layout: "Front-Engined All-Wheel Drive 8-speed Transmission", Price: "From $202,500", url: URL(string: "https://www.youtube.com/watch?v=K_9OsWMN-ac&ab_channel=Motorhunt")),
        Car(title: "Ferrari", image: "SF90", Engine: "4.0 L (3,990 cc) F154 FA twin-turbocharged V8", Layout: "Front-Engined All-Wheel drive.", Price: "From $625,000", url: URL(string: "https://www.youtube.com/watch?v=k1bB_mU4wq0&ab_channel=TopGear")),
        Car(title: "Bugatti", image: "BUGGA", Engine: "8.0L Quad-Turbocharged W16 1479 bhp  (1103 kW), 1180 lb⋅ft  (1600 N·m)", Layout: "Mid-Engined, All-Wheel Drive 7-speed Transmission", Price: "From $15.7 million", url: URL(string: "https://www.youtube.com/watch?v=PkkV1vLHUvQ&ab_channel=Bugatti")),
        Car(title: "Lamborgini", image: "LAMBO", Engine: "6.5L Naturally-Aspirated V12 740 bhp  (552 kW), 509 lb⋅ft  (690 N·m)", Layout: "Mid-Engined, All-Wheel Drive 7-speed Transmission", Price: "US$4,000,000", url: URL(string: "https://www.youtube.com/watch?v=ckjqW1M9zqw&ab_channel=Shmee150")),
        Car(title: "Mclearn AMG SLR", image: "AMGGT", Engine: "Front mid-engine, rear-wheel-drive", Layout: "Front mid-engine, rear-wheel-drive", Price: "From 2.6 Million", url: URL(string: "https://www.youtube.com/watch?v=r7Gk2gIIdLs&ab_channel=Gumbal")),
        Car(title: "Polester", image: "VOLVO", Engine: "2.0L B4204T48 in-line four twincharged petrol engine", Layout: "Transverse all-wheel drive with rear Electric motors", Price: "From $47,200", url: URL(string: "https://www.youtube.com/watch?v=s3FLr4FkjA4&ab_channel=DougDeMuro")),
        Car(title: "Tesla Roadster", image: "Tesla", Engine: "3-phase 4-pole AC induction motor", Layout: "Rear mid-motor, rear-wheel drive", Price: "From $200,000", url: URL(string: "https://www.youtube.com/watch?v=43mLmegVuWY&ab_channel=FutureUnity")),
        Car(title: "Porche", image: "PORC", Engine: "Curb weight: 3,164 lbs Engine: 4.0 L 6-cylinder", Layout: "Rear Wheel Drive", Price: "From $161,100", url: URL(string: "https://www.youtube.com/watch?v=wfu07Eq6pSc&ab_channel=DougDeMuro"))
        
    ]
}
