//
//  carListView.swift
//  Top10cars
//
//  Created by Consultant on 4/2/22.
//

import SwiftUI

struct carsListView: View {
    var cars: [Car] = CarList.topTen
    var body: some View {
        NavigationView{
            List(cars, id: \.id){ cars in
                NavigationLink(destination: CarListDetailView(car: cars), label:{
                    Image(cars.image)
                        .resizable()
                        .scaledToFit()
                        .frame(height: 65)
                        .cornerRadius(10)
                        .border(Color.black)
                        .background(Color.green)
                    
                    VStack(alignment: .leading){
                        Text(cars.title)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .minimumScaleFactor(1)
                         
                
                        VStack(alignment: .leading){
                            Text(cars.Engine)
                                .fontWeight(.bold)
                                .lineLimit(1)
                                .minimumScaleFactor(1)
                                .foregroundColor(Color.white)
                        }
                    }
                    .navigationTitle("Top 10 Cars")
                    .font(.callout)
                    .padding()
                    .background(Color.black)
                })
            }
        }
        
    }
}

struct carsListView_Previews: PreviewProvider {
    static var previews: some View {
        carsListView()
            .preferredColorScheme(.dark)
    }
}
