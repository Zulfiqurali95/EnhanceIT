//
//  CarListDetailView.swift
//  Top10cars
//
//  Created by Consultant on 4/2/22.
//

import SwiftUI

struct CarListDetailView: View {
    var car: Car
    var body: some View {
        NavigationView{
            
            VStack{
                Image(car.image)
                    .resizable()
                    .scaledToFit()
                    .frame( height: 300 )
                    .cornerRadius(40)
                
                Text(car.title)
                    .fontWeight(.bold)
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .foregroundColor(.red)
                
                Text(car.Price)
                    .fontWeight(.bold)
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .foregroundColor(.red)
                
                HStack{
                    Label(car.Engine, systemImage: "car.fill")
                    
                        .padding()
                        .foregroundColor(Color.red)
                    
                }
                
                Text(car.Layout)
                    .font(.body)
                    .padding()
                    .foregroundColor(.red)
                
                Link(destination:car.url!, label: {
                    Text("Watch the Specs")
                        .bold()
                        .font(.title3)
                        .frame(width: 200, height: 30, alignment: .center)
                        .background(Color(.white))
                        .foregroundColor(.red)
                    .cornerRadius(10)})
                
            }
            .navigationTitle(car.title)
            .font(.callout)
            
            
        }
        
    }
    
}






struct CarListDetailView_Previews: PreviewProvider {
    static var previews: some View {
        CarListDetailView(car: CarList.topTen.first!)
            .preferredColorScheme(.dark)
    }
}
