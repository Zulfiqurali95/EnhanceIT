//
//  Top10carsApp.swift
//  Top10cars
//
//  Created by Consultant on 4/2/22.
//

import SwiftUI

@main
struct Top10carsApp: App {
    var body: some Scene {
        WindowGroup {
            carsListView()
                .preferredColorScheme(.dark)
        }
    }
}
