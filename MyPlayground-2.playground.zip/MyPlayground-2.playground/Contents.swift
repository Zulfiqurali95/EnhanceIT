import UIKit
func longestCommonPrefix(_ strs: [String]) -> String {
    if strs.isEmpty {
        return "Empty"
    }
    
    if var prefixStr = strs.first {
        
        for index in 0..<strs.count {
            let str = strs[index]
            while str.contains(prefixStr) == false {
                let index = prefixStr.index(prefixStr.startIndex, offsetBy: prefixStr.count - 1)
                prefixStr = String(prefixStr[..<index])
                if prefixStr.count == 0 {
                    return "Empty"
                }
            }
        }
        return prefixStr
    }
    
    return "Empty"
}

var lcp = longestCommonPrefix(["overwork", "overdue", "overeat"])
print(lcp)
