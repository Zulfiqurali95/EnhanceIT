//
//  ViewController.swift
//  ProjectDecodeable
//
//  Created by Consultant on 3/2/22.
//

import UIKit

class ViewController: UIViewController {
    var heroes = [Hero]()
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
    }
    
    func setupTableView(){
        // tableView.backgroundColor = .red
        print("setting up tableview")
        fetchJson {
            self.tableView.reloadData()
        }
        tableView.delegate = self
        tableView.dataSource = self
        print("done setting up tableview")
    }
    func fetchJson(completed: @escaping ()->()) {
        print("fetching json")
        guard let url = URL(string: "https://api.opendota.com/api/heroStats") else { return }
        
        let session = URLSession.shared
        print("x")
        
        let task = session.dataTask(with: url) { data, response, error in
            
            guard error == nil else {
                print("Error: \(error?.localizedDescription ?? "Something happened here")")
                return
            }
            
            guard let response = response as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
                print("server error!")
                return
            }
            
            guard data != nil else {
                print("Error: We have no data bub")
                return
            }
            
            do {
                // instead of first serializing the json with JSONSerialization class or associated functions we can instead let the instance of our array of heroes hold the decoded data directly.
                self.heroes = try JSONDecoder().decode([Hero].self, from: data!)
                
                DispatchQueue.main.async {
                    // here we call the closure to indicate this is where the results of the fetch should be used
                    completed()
                }
                
            } catch {
                print("Errors: \(error.localizedDescription)")
            }
            
        }
        task.resume()
        print("done fetching json")
    }
}


extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return heroes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print("cell for row at called")
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = heroes[indexPath.row].name.capitalized
        print("cell for row at done")
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("performing segue")
        performSegue(withIdentifier: "detailSegue", sender: self)
        print("done performing segue")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? DetailViewController {
            destination.hero = heroes[(tableView.indexPathForSelectedRow?.row)!]
        }
    }
}





