//
//  ExtensionUserdefualt.swift
//  ProjectDecodeable
//
//  Created by Consultant on 3/9/22.
//

import Foundation
import UIKit
extension UserDefaults {
    private enum UserDefaultsKeys: String {
        case switchIsOn
        case signedInUser
    }
    
    var switchIsOn:Bool {
        get {
            bool(forKey: UserDefaultsKeys.switchIsOn.rawValue)
        }
        set {
            setValue(newValue, forKey: UserDefaultsKeys.switchIsOn.rawValue)
        }
    }
    
    var signedInUser: Hero? {
        get {
            if let data = object(forKey: UserDefaultsKeys.signedInUser.rawValue) as? Data {
                _ = try? JSONDecoder().decode(Hero.self, from: data)
            }
            return nil
        }
        set {
            if newValue == nil {
                removeObject(forKey: UserDefaultsKeys.signedInUser.rawValue)
            } else {
                let data = try? JSONEncoder().encode(newValue)
                setValue(data, forKey: UserDefaultsKeys.signedInUser.rawValue)
            }
        }
    }
}
