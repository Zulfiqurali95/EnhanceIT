//
//  DetailViewController.swift
//  ProjectDecodeable
//
//  Created by Consultant on 3/2/22.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var Image: UIImageView!
    @IBOutlet weak var Namelb1: UILabel!
    @IBOutlet weak var attributeslb1: UILabel!
    @IBOutlet weak var attacklb1: UILabel!
    @IBOutlet weak var legs: UILabel!
    
    var hero: Hero?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Namelb1.text = hero?.name
        attacklb1.text = hero?.primaryAttribute
        attacklb1.text = hero?.attackType
        legs.text = "\((hero?.legs)!)"
        let baseUrl = "https://api.opendota.com" + (hero?.image)!
        let url = URL(string: baseUrl)
        Image.getImage(from: url!)
    }
    
    
}
