import UIKit

//1
let firstName = "Matt"
if (firstName == "Matt") {
  let lastName = "Galloway"
} else if firstName == "Ray" {
  let lastName = "Wenderlich"
}
let fullName = firstName + " " + lastName
