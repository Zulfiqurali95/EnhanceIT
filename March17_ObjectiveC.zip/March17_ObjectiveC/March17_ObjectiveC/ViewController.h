//
//  ViewController.h
//  March17_ObjectiveC
//
//  Created by Consultant on 3/17/22.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIView *clickhereView;
@property (weak, nonatomic) IBOutlet UILabel *clickhereLabel;


@end

