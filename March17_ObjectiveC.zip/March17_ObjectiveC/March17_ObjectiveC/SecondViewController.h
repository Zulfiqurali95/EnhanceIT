//
//  SecondViewController.h
//  March17_ObjectiveC
//
//  Created by Consultant on 3/17/22.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
@protocol AddCountryDelagate <NSObject>
-(void) addCountry: (NSString *) countryName;


@end

@interface SecondViewController : ViewController
@property (nonatomic, weak) id <AddCountryDelagate> delegate;

@property (nonatomic, weak) ViewController *firstVC;

@property (nonatomic, copy) void (^selectedCountry)(NSString *);

-(void) getLastCountry : (void(^)(NSString *))selectedCountry;


@end

