//
//  ValidationService.swift
//  March14TestDataTests
//
//  Created by Consultant on 3/15/22.
//

import XCTest


@testable import March14TestData
class ValidationServiceTest : XCTestCase{
    var validation: ValidationService!
    
    
    override func setUp() {
        super.setUp()
        validation = ValidationService()
    }
    
    
    override func tearDown() {
        super.tearDown()
        validation = nil
    }
    func test_username_is_nil(){
        let expectedError = ValidationError.invalidEntry
        var error:ValidationError?
        
        XCTAssertThrowsError(try validation.validateUserName(nil)) {
        thrownError in
        error = thrownError as? ValidationError
    }
        XCTAssertEqual(expectedError, error)
    }
    func is_valid_username() throws {
        XCTAssertNoThrow(try validation .validateUserName("admin"))
    }
    
}
