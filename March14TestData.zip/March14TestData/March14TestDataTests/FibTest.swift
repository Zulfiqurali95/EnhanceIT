//
//  FibTest.swift
//  March14TestDataTests
//
//  Created by Consultant on 3/15/22.
//

import Foundation
import XCTest
@testable import March14TestData
class FibTest: XCTestCase{
    
    func testFibSequence(){
    let expectedReturn = [0,1,1,2,3]
    var fibonacci = [0,1]
    
    for i in 2...4{
        fibonacci.append(i)
        fibonacci[i] = fibonacci[i-1] + fibonacci[i-2]
    }
    XCTAssertEqual(expectedReturn, fibonacci)
}
}
