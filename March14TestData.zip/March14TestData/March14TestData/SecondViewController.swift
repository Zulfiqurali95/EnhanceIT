//
//  SecondViewController.swift
//  March14TestData
//
//  Created by Consultant on 3/15/22.
//

import Foundation
import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var resultLb1: UILabel!
    
    @IBOutlet weak var inputTextField: UITextField!
    
    @IBOutlet weak var CalculateFibButton: UIButton!
    
    var userInput: String {
        return (inputTextField.text)!
        
    }
    var fibNum: Int {
        return Int(userInput)!
        
    }
    
    
    

override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
}
    @IBAction func calculateButtonTappedf(_ sender: Any) {
        
        guard fibNum > 0 else{ return }
        var fibonacci = [0,1]
        for i in 2...fibNum{
            fibonacci.append(i)
            fibonacci[i] = fibonacci[i-1] + fibonacci[i-2]
        }
        resultLb1.text = "\(fibonacci)"
    }
}
