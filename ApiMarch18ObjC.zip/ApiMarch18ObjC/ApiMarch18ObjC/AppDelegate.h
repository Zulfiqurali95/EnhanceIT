//
//  AppDelegate.h
//  ApiMarch18ObjC
//
//  Created by Consultant on 3/20/22.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

