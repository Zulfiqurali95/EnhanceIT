//
//  SceneDelegate.h
//  ApiMarch18ObjC
//
//  Created by Consultant on 3/20/22.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

