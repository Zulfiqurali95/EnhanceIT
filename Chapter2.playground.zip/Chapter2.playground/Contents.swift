import UIKit
var A: Int = 100
var B: Double = 12.5
//integer = decimal // warningg
A = Int(B) //WARNING killer
let hourlyRate: Double = 19.5
let hoursWorked: Int = 10
//let totalCost: Double = hourlyRate * hoursWorked WARNING//
let totalCost: Double = hourlyRate * Double(hoursWorked) //WARNING killer
let typeInferredInt = 42
let typeInferredDouble = 3.14159
let wantADouble = 3
let actuallyDouble = Double(3)
let actuallyDouble2: Double = 3
let actuallyDouble3 = 3 as Double

let coordinates = (2,3) //1

let namedCoordinate = (x:2,y:3) //2
//3
let character: Character = "g"
let string: String = "Dog"
let string2: String = "🐶"
let characterDog: Character = "🐶"
let character2: Character = "🐶"
//4
let tuple = (day: 15, month: 8, year: 2015)
let day = tuple.day
//5
var name = "Matt"
name += " Galloway"
//6
let tuple2 = (100, 1.5, 10)
let value = tuple.1 // TYPE INFERENCE
// 7
let tuple3 = (day: 15, month: 8, year: 2015)
let month = tuple3.month //8]

//8
let number = 10
let multiplier = 5
let summary = "\(number) multiplied by \(multiplier) equals \(number * multiplier)" // String
//9
let a = 4
let b: Int32 = 100
let c: UInt8 = 12
let d : Int = a * Int(b) * Int(c)
let result = a + Int(b) - Int(c) // 92
let f : Int = a + Int(b) - Int(c)
//10
//Double can represent the value of π more accurately, because it uses more bits to get more precision

