//
//  Movie.swift
//  ThursdayProjectApi
//
//  Created by Consultant on 3/3/22.
//

import Foundation
struct Movie:Codable{
let original_title:String
let poster_path:String?
let popularity:Float
let overview:String?
    }



