//
//  ViewController.swift
//  March23Audio
//
//  Created by Consultant on 3/23/22.
//

import UIKit
import AVFoundation
class ViewController: UIViewController {

    @IBOutlet weak var playButton: UIButton!
    
    var player: AVAudioPlayer?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func playTapped(_ sender: Any) {
        if let player = player, player.isPlaying {
            player.stop()
            playButton.setTitle("Play", for: .normal)
            
        } else {
            playButton.setTitle("Stop", for: .normal)
            do {
                try AVAudioSession.sharedInstance().setMode(.default)
                try AVAudioSession.sharedInstance().setActive(true, options: .notifyOthersOnDeactivation)
                
                let urlString = Bundle.main.path(forResource:"01 - Bobby McFerrin _ Jack Nicholson - The Elephant_s Child", ofType: "flac")
                guard let urlString = urlString else {
                    return
                }

                player = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: urlString))
                
                guard let player = player else {
                    return
                }
                player.play()

            } catch {
                print("Error")
            }
        }
    }
    

}

