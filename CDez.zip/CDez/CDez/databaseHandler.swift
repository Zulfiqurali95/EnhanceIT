//
//  databaseHandler.swift
//  CDez
//
//  Created by Consultant on 3/10/22.
//

import UIKit
import CoreData
class databaseHandler {
    
    private let viewContext: NSManagedObjectContext!
        
        static let shared = databaseHandler()
        
        init(){
            viewContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        }
    // any object that can act with an NSManagedObject
    // returns a generic object
    func add<T:NSManagedObject>(_ type:T.Type) -> T? {
        
        // names the entity
        guard let entityName = T.entity().name else { return nil }
        
        // assigns the entity as an entity variable
        guard let entity = NSEntityDescription.entity(forEntityName: entityName, in: viewContext) else { return nil }
        
        // assigns generic object as entity
        let object = T(entity: entity, insertInto: viewContext)
        
        // returns the generic object
        return object
    }
    
    // fetches all generic objects/records
    func fetch<T: NSManagedObject>(_ type: T.Type) -> [T] {
        let request = T.fetchRequest()
        do {
            let result = try viewContext.fetch(request)
            return result as! [T]
        } catch {
            print(error.localizedDescription)
            return []
        }
    }
    
    // saves the view context
    func save() {
        do {
            try viewContext.save()
        } catch {
            print(error.localizedDescription)
        }
    }
    
    // deletes the view context then saves the result
    func delete<T: NSManagedObject>(_ object:T) {
        viewContext.delete(object)
        save()
    }
}
