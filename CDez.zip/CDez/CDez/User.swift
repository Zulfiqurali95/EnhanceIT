//
//  User.swift
//  CDez
//
//  Created by Consultant on 3/10/22.
//

import Foundation
import CoreData

//public class User: NSManagedObject {
//    @NSManaged var age:Int16
//    @NSManaged var createdDate:Date
//    @NSManaged var name:String
//}

public class User: NSManagedObject{
    @NSManaged var avatar: String
    @NSManaged var id: Int16
    @NSManaged var email: String
    @NSManaged var firstName: String
    @NSManaged var lastName: String
}
