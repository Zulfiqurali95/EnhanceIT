//
//  ViewController.swift
//  CDez
//
//  Created by Consultant on 3/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var ageTextField: UITextField!
    @IBOutlet weak var tableview: UITableView!
    
    //create instance of databasehandler
    let database = databaseHandler()
    var users: [User]?{
        didSet{
            /*
             with theee diset prop obs the code below executes whenever the prop has changed that means for us the arr of user obj is updated when we reload the tableview in real time
             https://nshipster.com/swift-property-observers
             */
            DispatchQueue.main.async {
                self.tableview.reloadData()
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupDelegates()
        //tableview.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableview.tableFooterView = UIView(frame: .zero)
        view.layer.cornerRadius = 10
        tableview.layer.cornerRadius = 10
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //step 1
        //let results = database.fetch(User.self)
        users = database.fetch(User.self)
        
        // check to see if we are saving to core data
        //print(results.map{$0.name})
    }
    
    override func viewDidAppear(_ animated: Bool) {
        APIHandler.shared.syncUsers { [weak self] in
            self?.users = self?.database.fetch(User.self)
        }
    }

    @IBAction func saved(_ sender: Any) {
        // calling save to persist data
        save()
    }
    
    // MARK: - Helper Functions
    func setupDelegates(){
        tableview.dataSource = self
        tableview.delegate = self
    }
    
    func save(){
        guard let user = database.add(User.self) else {return}
//        guard let name = nameTextField.text, let ageText = ageTextField.text, let age = Int16(ageText) else {return}
//        user.name = name
//        user.age = age
//        user.createdDate = Date()
//        users?.append(user)
//        database.save()
    }
    
}

extension ViewController: UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserTableViewCell") as! UserTableViewCell
//        cell = UITableViewCell(style: .value1, reuseIdentifier: "UserTableViewCell")
//        cell.layer.cornerRadius = 10
//        let entity = users?[indexPath.row]
        cell.user = users?[indexPath.row]
//        cell.textLabel?.text = "\((entity?.firstName)!) \((entity?.lastName)!)"
//        cell.detailTextLabel?.text = "\((entity?.email)!)"
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath){
        switch editingStyle{
        case .insert:
            print("inserting...")
        case .delete:
            print("deleting...")
            guard let user = users?[indexPath.row] else {return}
            //begin a series of method calls that inset, delete or select rows and sectioon of the table view
            tableview.beginUpdates()
            users?.remove(at: indexPath.row)
            //delet user from coredata
            database.delete(user)
            tableview.deleteRows(at: [indexPath], with: .automatic)
            // conculdes a seriees of method calls ...
            tableview.endUpdates()
        default:
            break
        }
    }
    
}

class UserTableViewCell: UITableViewCell{
    
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var emailLbl: UILabel!
    
    
    var user: User?{
        didSet{
            setupCell()
        }
    }
    
    private func setupCell(){
        guard let user = user else {return}
        let url = URL(string: user.avatar)
        userImage.getImage(from: url!)
        nameLbl.text = "\((user.firstName)) \((user.lastName))"
        emailLbl.text = user.email
    }
    
    override func prepareForReuse() {
        userImage.image = nil
        nameLbl.text = nil
        emailLbl.text = nil
    }

}

extension UIImageView {
    func getImage(from url: URL, contentMode mode: ContentMode = .scaleAspectFit) {
        contentMode = mode
        let session = URLSession.shared
        let task = session.dataTask(with: url) { data, response, error in
            guard let httpURLResponse = response as? HTTPURLResponse, httpURLResponse.statusCode == 200 else { return }
            guard let mimeType = response?.mimeType, mimeType.hasPrefix("image") else { return }
            guard let data = data, error == nil else { return }
            guard let image = UIImage(data: data) else { return }
            
            DispatchQueue.main.async {
                self.image = image
            }
        }
        task.resume()
    }
}
