//: [Previous](@previous)

import Foundation
extension String{
    func CharArray() -> Array<Character> {
     return Array(self)
    }
}
struct Validation {
    
    static func isValid(_ s: String) -> Bool {
        let charArr = s.CharArray()
        let dict: Dictionary<Character, Character> = [
            "}":"{",
            "]":"[",
            ")":"(",
            "a":"b",
            "c":"d",
            "f":"e"
        ]
        var stack: Array<Character> = []
        for char in charArr {
            if char == "}" || char == ")" || char == "]" {
            if stack.isEmpty || stack.last != dict[char] {
                    return false
                } else {
                    stack.removeLast()
                }
            } else {
                stack.append(char)
            }
        }
        return stack.isEmpty
    
        }
}
 

