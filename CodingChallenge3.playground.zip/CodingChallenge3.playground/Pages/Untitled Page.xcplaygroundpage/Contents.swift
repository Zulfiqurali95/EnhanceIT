import Foundation

private extension String {
    func randomAccessCharacterArray() -> Array<Character> {
        return Array(self)
    }
}

struct Easy_020_Valid_Parentheses {
    
    static func isValid(_ s: String) -> Bool {
        let charArr = s.randomAccessCharacterArray()
        let dict: Dictionary<Character, Character> = [
            "}":"{",
            "]":"[",
            ")":"("
        ]
        var stack: Array<Character> = []
        for char in charArr {
            if char == "}" || char == ")" || char == "]" {
                if stack.isEmpty || stack.last != dict[char] {
                    return false
                } else {
                    stack.removeLast()
                }
            } else {
                stack.append(char)
            }
        }
        return stack.isEmpty
    }
    
}


