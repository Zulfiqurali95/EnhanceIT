//
//  ViewController.swift
//  March22Mapkit
//
//  Created by Consultant on 3/22/22.
//

import UIKit
import MapKit
import CoreLocation
class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var mapView: MKMapView!
    private let locationManager = CLLocationManager()
    private let userRadiusInMeters: Double = 1000
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.delegate = self
        checkAuthStatus()
        // Do any additional setup after loading the view.
    }
    /* in your simulator you can simulate location by selecting the simulation and from the top menu select debug --> Siumlate location. Lets go ahead and do that .*/
    /** for ATL = lat 33.7490 long = 84.3880
         for London Lat = 52.5072 Long = 0.1272
     
     CORE Location FRAMEWORK : CORE LOCATION PROVIDS SERVICES THAT DETERMIE A DEVICE'S GEOGRAPIC LOCATION, ALLTITUDE AND ORENTATION OR ITS POSTION RELATIVE TO NEARBY IBEACON DEVICE. THE FRAMEWORK GATHERS DATA  USING ALL AVAILBLE COMPONENTS ON THE DEVICES, INCLUDING THE WIFI, GPS , BLUETOOTH, MAGOMETER, BAROMETER AND CELLULAR HARDWARE.
     HTTPS://DEVELOPER.APPLE.COM/DOCUMENTATION/CORELOCATION
     WHATS NEW IN LOCATION WWDC'20
     HTTPS:DEVELOPER.APPLE.COM/VIDEOS/PLAY/WWDC2020/10660
     
     */
    
    private func setupLocationService() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    }

    private func checkAuthStatus() {
        switch locationManager.authorizationStatus{
        case.restricted, .denied:
            break
        case.notDetermined:
            locationManager.requestWhenInUseAuthorization()
            // like delegates we can also set show user location in the interface builder
            mapView.showsUserLocation = true
        case.authorizedAlways:
            mapView.showsUserLocation = true
         grokUserLocation()
            locationManager.startUpdatingLocation()
        case.authorizedWhenInUse:
            mapView.showsUserLocation =  true
            grokUserLocation()
        @unknown default:
            break
        }
    }
    
    private func grokUserLocation(){
        
        if let location = locationManager.location?.coordinate{
            let region = MKCoordinateRegion.init(center: location, latitudinalMeters: userRadiusInMeters, longitudinalMeters: userRadiusInMeters)
            
            mapView.setRegion(region, animated: true)
        }
    }
    
    private func locationServicesCheck(){
        // is geolocation even enabled on device?
        if CLLocationManager.locationServicesEnabled(){
            //if yes lets set up our location manager and services
            setupLocationService()
            checkAuthStatus()
        } else {
            print("ok, fine then.....")
        }
    }
}
extension ViewController{
    func locationManager(_ manager: CLLocationManager, didUpdatateLocation location: [CLLocation]){
        
        // grabs an array of location in order to build a history of coordinates. from this we wcan determine head/dirction with some other built in methods.
        
        
        guard let location = location.last else{
            return
        }
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion.init(center: center, latitudinalMeters: userRadiusInMeters, longitudinalMeters: userRadiusInMeters)
        mapView.setRegion(region, animated: true)
    }
    
    
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        checkAuthStatus()
    }
}

